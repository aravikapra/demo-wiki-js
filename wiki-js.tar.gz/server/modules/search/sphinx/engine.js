module.exports = {
  activate() {

  },
  deactivate() {

  },
  query() {

  },
  created() {

  },
  updated() {

  },
  deleted() {

  },
  renamed() {

  },
  rebuild() {

  }
}
