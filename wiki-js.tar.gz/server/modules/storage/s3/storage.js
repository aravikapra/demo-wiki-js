const S3CompatibleStorage = require('./common')

module.exports = new S3CompatibleStorage('S3')
